<?php
session_start();

if(!$_SESSION['email'])
{
    header("Location: login.php");//redirect to login page to secure the welcome page without login access.
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>My HomePage</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="css/style.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script src="js/jquery-2.2.1.min.js"></script>
  	<script src="js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Welcome...</h2>
  <?php
  echo $_SESSION['email'];
  ?>
<h2><a href="logout.php">Logout</a> </h2>

</div>
</body>
</html>


