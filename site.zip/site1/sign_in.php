<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>My Site</title>
		<link href="css/style.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
		<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
		<script src="js/jquery-2.2.1.min.js"></script>
    	<script src="js/jquery.validate.min.js"></script>
    </head>
    <body>
        <div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <div class="container">
                <div class="navbar-header">
                   <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.html"><img src="" data-active-url="" alt="">Your Logo
                    <!--<sub class="navtag">small text</sub>-->
                    </a>
                </div>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="about.html">About Us</a></li>
                        <li><a href="services.html">Services</a></li>
                        <li><a href="careers.html">Careers</a></li>
                        <li><a href="contact.php">Contact Us</a></li>
                        <li class="active"><a href="sign_in.php">Sign In</a></li>
                    </ul>
                </div>
            </div>
        </div><br>

 <div class="container">
	<div class="row">
		<div class="col-lg-12">
			<h2 class="page-header">Contact Us</h2>
			<ol class="breadcrumb">
				<li><a href="index.html">Home</a></li>
				<li class="active">Contact Us</li>
		  </ol>
	   </div>
	</div>
</div>

<div class="container"><!-- container class is used to centered  the body of the browser with some decent width-->
    <div class="row"><!-- row class is used for grid system in Bootstrap-->
        <div class="col-md-4 col-md-offset-4"><!--col-md-4 is used to create the no of colums in the grid also use for medimum and large devices-->
            <div class="panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title">Registration</h3>
                </div>
                <div class="panel-body">
                    <form role="form" method="post" action="sign_in.php" id="reg" novalidate="novalidate">
                        <fieldset>
                            <div class="form-group">
                                <input class="form-control" placeholder="Username" name="name" type="text" autofocus>
                            </div>

                            <div class="form-group">
                                <input class="form-control" placeholder="E-mail" name="email" type="email" autofocus>
                            </div>
                            <div class="form-group">
                                <input class="form-control" placeholder="Password" name="pass" type="password" value="">
                            </div>


                            <input class="btn btn-lg btn-success btn-block" type="submit" value="register" name="register" data-toggle="model" data-target="#model">

                        </fieldset>
                    </form>
                    <center><b>Already registered ?</b> <br></b><a href="login.php">Login here</a></center><!--for centered text-->
                </div>
            </div>
        </div>
    </div>
</div>

<section>&nbsp;</section>

<div id="footer">
	<div class="row">
		<div class="col-md-5">
			<h4>Write Us</h4>
			<hr>
			<form>
				<div class="row">
					<div class="col-md-6 col-sm-6">
						<div class="form-group">
							<input type="text" class="form-control" required="required" placeholder="Name">
						</div>
					</div>
					<div class="col-md-6 col-sm-6">
						<div class="form-group">
							<input type="email" class="form-control" required="required" placeholder="Email address">
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12 col-sm-12">
						<div class="form-group">
							<textarea name="message" id="message" required="required" class="form-control" rows="3" placeholder="Message"></textarea>
						</div>
						<div class="form-group">
							<button type="submit" class="btn btn-primary">Submit Request</button>
						</div>
					</div>
				</div>
			</form>
		</div>
		<div class="col-md-4">
			<h4>Contact Info</h4>
			<hr>
			<h4>XYZ Solutions</h4>
			<h5>110, New Street,</h5>
			<p>Sydney, Australia<br></p>
			<p><i class="fa fa-phone icon_color"></i> <abbr title="Phone">P</abbr>: +23-01-02-003</p>
		<p><i class="fa fa-envelope-o icon_color"></i> <abbr title="Email">E</abbr>: <a href="mailto:mail@yourdomain.com">mail@yourdomain.com</a></p>
		</div>

	   <div class="col-md-3 social">
		<h4>Follow Us</h4>
			<hr>
			<a href="#"><i class="fa fa-facebook-square fa-2x"></i></a>
			<a href="#"><i class="fa fa-twitter-square fa-2x"></i></a>
			<a href="#"><i class="fa fa-google-plus-square fa-2x"></i></a>
			<a href="#"><i class="fa fa-linkedin-square fa-2x"></i></a>
			<a href="#"><i class="fa fa-pinterest-square fa-2x"></i></a>
		</div>
	</div>

	<div class="row">
		<div class="col-md-12 text-center">
		2016 <a href="#">www.yourdomain.com</a> | All Right Reserved
		</div>
	</div>
    <script src="js/bootstrap.min.js"></script>
</div>

<script>
$(document).ready(function(){
   $("#reg").validate({
      rules: {
				  name: "required",
				  email: {
					  required: true,
					  email: true
				  },
				  pass: {
					  required: true,
					  minlength: 5
				  }
			  },
			  messages: {
				  name: "Please enter your name...",
				  pass: {
					  required: "Please provide a password...",
					  minlength: "Your password must be at least 5 characters long..."
				  },
				  email: "Please enter a valid email address..."
           }
     });
});

</script>
</body>
</html>

<?php
include("database/db_conection.php");//make connection here

if(isset($_POST['register']))
{
    $user_name=$_POST['name'];//here getting result from the post array after submitting the form.
    $user_pass=$_POST['pass'];//same
    $user_email=$_POST['email'];//same

    $insert_user="insert into users (user_name,user_pass,user_email) VALUE ('$user_name','$user_pass','$user_email')";
    if(mysqli_query($dbcon,$insert_user))
    {
        echo "<script>alert('You have registered successfully..You can login now!!!')</script>";
    }
    else {
	    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
}
?>